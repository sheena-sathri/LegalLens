"""LegalLens — Streamlit Frontend"""

import streamlit as st
import requests
import json
import time

API_BASE = "http://localhost:8000/api/v1"

st.set_page_config(
    page_title="LegalLens",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
)

# --- Sidebar ---
st.sidebar.title("🔍 LegalLens")
st.sidebar.caption("AI-Powered Legal Document Intelligence")
page = st.sidebar.radio(
    "Navigate",
    ["📄 Upload & Classify", "⚖️ Clause Analysis", "💬 Ask Questions", "🔄 Compare", "📊 Governance"],
)

# --- Helper Functions ---
def api_get(endpoint: str):
    try:
        resp = requests.get(f"{API_BASE}{endpoint}", timeout=30)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        st.error(f"API Error: {e}")
        return None

def api_post(endpoint: str, json_data: dict = None, files: dict = None):
    try:
        resp = requests.post(f"{API_BASE}{endpoint}", json=json_data, files=files, timeout=120)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        st.error(f"API Error: {e}")
        return None

def get_documents():
    result = api_get("/documents/")
    return result.get("documents", []) if result else []


# ============================================================
# PAGE: Upload & Classify
# ============================================================
if page == "📄 Upload & Classify":
    st.title("📄 Upload & Classify Documents")
    st.markdown("Upload legal documents (PDF, DOCX, TXT) for automatic classification and analysis.")

    col1, col2 = st.columns([1, 1])

    with col1:
        st.subheader("Upload")
        uploaded_file = st.file_uploader(
            "Choose a legal document",
            type=["pdf", "docx", "txt"],
            help="Supported: PDF, DOCX, TXT"
        )

        if uploaded_file and st.button("🚀 Upload & Process", type="primary"):
            with st.spinner("Processing document..."):
                files = {"file": (uploaded_file.name, uploaded_file.getvalue(), uploaded_file.type)}
                result = api_post("/documents/upload", files=files)

            if result:
                st.success(f"✅ Uploaded: {result['filename']}")
                st.json(result)

                # Auto-classify
                with st.spinner("🤖 Classifying document..."):
                    classify_result = api_post(f"/analysis/classify/{result['document_id']}")

                if classify_result and "classification" in classify_result:
                    cls = classify_result["classification"]
                    st.subheader("Classification Result")

                    col_a, col_b = st.columns(2)
                    col_a.metric("Document Type", cls.get("document_type", "Unknown"))
                    col_b.metric("Confidence", f"{cls.get('confidence', 0):.0%}")

                    if cls.get("reasoning"):
                        st.info(f"💡 {cls['reasoning']}")

                    if cls.get("metadata"):
                        st.subheader("Extracted Metadata")
                        st.json(cls["metadata"])

    with col2:
        st.subheader("Document Library")
        docs = get_documents()
        if docs:
            for doc in docs:
                cls_data = json.loads(doc["classification"]) if doc.get("classification") else None
                doc_type = cls_data.get("document_type", "Unclassified") if cls_data else "Unclassified"

                with st.expander(f"📁 {doc['filename']} — {doc_type}"):
                    st.text(f"ID: {doc['document_id']}")
                    st.text(f"Type: {doc['file_type']} | Pages: {doc.get('page_count', '?')}")
                    st.text(f"Status: {doc.get('status', 'unknown')}")
                    st.text(f"Uploaded: {doc.get('created_at', '')}")
        else:
            st.info("No documents uploaded yet. Upload your first document above!")


# ============================================================
# PAGE: Clause Analysis
# ============================================================
elif page == "⚖️ Clause Analysis":
    st.title("⚖️ Clause Extraction & Risk Assessment")

    docs = get_documents()
    if not docs:
        st.warning("No documents found. Please upload a document first.")
    else:
        doc_options = {f"{d['filename']} ({d['document_id']})": d['document_id'] for d in docs}
        selected = st.selectbox("Select a document", options=list(doc_options.keys()))
        document_id = doc_options[selected]

        if st.button("🔍 Extract & Analyze Clauses", type="primary"):
            with st.spinner("🤖 Analyzing clauses... (this may take 30-60 seconds)"):
                result = api_post(f"/analysis/extract/{document_id}")

            if result and "extraction" in result:
                extraction = result["extraction"]

                # Summary
                st.subheader("📋 Summary")
                st.write(extraction.get("summary", ""))

                # Risk distribution
                meta = extraction.get("metadata", {})
                risk_dist = meta.get("risk_distribution", {})
                if risk_dist:
                    st.subheader("Risk Distribution")
                    cols = st.columns(4)
                    colors = {"LOW": "🟢", "MEDIUM": "🟡", "HIGH": "🟠", "CRITICAL": "🔴"}
                    for i, (level, count) in enumerate(risk_dist.items()):
                        cols[i % 4].metric(f"{colors.get(level, '')} {level}", count)

                # Clauses
                st.subheader("Extracted Clauses")
                for clause in extraction.get("clauses", []):
                    risk = clause.get("risk_level", "LOW")
                    icon = {"LOW": "🟢", "MEDIUM": "🟡", "HIGH": "🟠", "CRITICAL": "🔴"}.get(risk, "⚪")

                    with st.expander(f"{icon} {clause.get('clause_type', 'Unknown')} — {risk} risk"):
                        st.markdown(f"**Section:** {clause.get('section_reference', 'N/A')}")
                        st.markdown(f"**Text:** {clause.get('text', '')}")
                        st.markdown(f"**Risk Reason:** {clause.get('risk_reason', '')}")
                        if clause.get("playbook_note"):
                            st.info(f"📖 Playbook: {clause['playbook_note']}")

                # Performance
                st.caption(f"⏱️ Analysis completed in {result.get('latency_ms', 0)}ms | Tokens: {result.get('usage', {})}")


# ============================================================
# PAGE: Ask Questions (RAG)
# ============================================================
elif page == "💬 Ask Questions":
    st.title("💬 Ask Questions About Your Documents")
    st.markdown("Use natural language to query across your document knowledge base.")

    docs = get_documents()

    # Document filter
    filter_docs = st.multiselect(
        "Filter to specific documents (optional)",
        options=[f"{d['filename']} ({d['document_id']})" for d in docs],
        help="Leave empty to search all documents"
    )
    doc_ids = [d['document_id'] for d in docs if f"{d['filename']} ({d['document_id']})" in filter_docs] or None

    # Query input
    query = st.text_area(
        "Your question",
        placeholder="e.g., Which contracts have unlimited liability? What is the termination notice period in the MSA?",
        height=100,
    )

    if st.button("🔎 Search & Answer", type="primary") and query:
        with st.spinner("🤖 Searching and generating answer..."):
            result = api_post("/search/ask", json_data={
                "query": query,
                "document_ids": doc_ids,
                "top_k": 5,
            })

        if result:
            # Answer
            st.subheader("Answer")
            st.markdown(result.get("answer", "No answer generated."))

            # Confidence
            confidence = result.get("confidence", 0)
            conf_color = "🟢" if confidence > 0.8 else "🟡" if confidence > 0.5 else "🔴"
            st.caption(f"{conf_color} Confidence: {confidence:.0%}")

            if result.get("caveats"):
                st.warning(f"⚠️ {result['caveats']}")

            # Citations
            citations = result.get("citations", [])
            if citations:
                st.subheader("📚 Citations")
                for i, cite in enumerate(citations):
                    with st.expander(f"Source {i+1}: {cite.get('document_id', 'Unknown')} — {cite.get('section', '')}"):
                        st.markdown(cite.get("chunk_text", ""))

            st.caption(f"⏱️ {result.get('latency_ms', 0)}ms | {result.get('chunks_retrieved', 0)} chunks retrieved")

    # Example queries
    st.markdown("---")
    st.subheader("💡 Example Queries")
    examples = [
        "What are the termination provisions across all uploaded contracts?",
        "Which documents have data protection or GDPR clauses?",
        "Summarize the liability limitations in the MSA",
        "What are the payment terms and schedule?",
        "Are there any non-compete or non-solicitation clauses?",
    ]
    for ex in examples:
        st.code(ex, language=None)


# ============================================================
# PAGE: Compare
# ============================================================
elif page == "🔄 Compare":
    st.title("🔄 Contract Comparison")
    st.markdown("Compare two versions of a contract to identify semantic differences.")

    docs = get_documents()
    if len(docs) < 2:
        st.warning("Please upload at least 2 documents to use the comparison feature.")
    else:
        doc_options = {f"{d['filename']} ({d['document_id']})": d['document_id'] for d in docs}

        col1, col2 = st.columns(2)
        with col1:
            doc_a = st.selectbox("Original Version", options=list(doc_options.keys()), key="doc_a")
        with col2:
            doc_b = st.selectbox("Revised Version", options=list(doc_options.keys()), key="doc_b")

        if st.button("🔄 Compare Documents", type="primary"):
            doc_a_id = doc_options[doc_a]
            doc_b_id = doc_options[doc_b]

            if doc_a_id == doc_b_id:
                st.error("Please select two different documents.")
            else:
                with st.spinner("🤖 Comparing documents..."):
                    result = api_post("/analysis/compare", json_data={
                        "doc_a_id": doc_a_id,
                        "doc_b_id": doc_b_id,
                    })

                if result and "comparison" in result:
                    comp = result["comparison"]

                    st.subheader("Summary")
                    st.write(comp.get("summary", ""))

                    if comp.get("new_risks"):
                        st.error("🚨 New Risks Identified")
                        for risk in comp["new_risks"]:
                            st.markdown(f"- {risk}")

                    if comp.get("recommendation"):
                        st.info(f"📋 Recommendation: {comp['recommendation']}")

                    st.subheader("Changes")
                    for change in comp.get("changes", []):
                        icon = {"added": "🟢", "removed": "🔴", "modified": "🟡"}.get(change.get("type"), "⚪")
                        with st.expander(f"{icon} {change.get('clause', 'Unknown')} — {change.get('type', '')}"):
                            if change.get("original"):
                                st.markdown(f"**Original:** {change['original']}")
                            if change.get("revised"):
                                st.markdown(f"**Revised:** {change['revised']}")
                            st.markdown(f"**Risk Impact:** {change.get('risk_impact', 'N/A')}")


# ============================================================
# PAGE: Governance
# ============================================================
elif page == "📊 Governance":
    st.title("📊 Governance & Audit Trail")

    result = api_get("/governance/audit/report")

    if result:
        # Summary metrics
        col1, col2, col3 = st.columns(3)
        col1.metric("Total Operations", result.get("total_operations", 0))
        col2.metric("Avg Latency", f"{result.get('average_latency_ms', 0)}ms")
        col3.metric("Actions Tracked", len(result.get("action_breakdown", {})))

        # Action breakdown
        breakdown = result.get("action_breakdown", {})
        if breakdown:
            st.subheader("Action Breakdown")
            for action, count in breakdown.items():
                st.progress(count / max(breakdown.values()), text=f"{action}: {count}")

        # Audit logs table
        st.subheader("Recent Audit Logs")
        logs = result.get("logs", [])
        if logs:
            st.dataframe(
                logs,
                column_config={
                    "timestamp": "Time",
                    "action": "Action",
                    "document_id": "Document",
                    "input_summary": "Input",
                    "output_summary": "Output",
                    "latency_ms": "Latency (ms)",
                    "confidence": "Confidence",
                },
                hide_index=True,
                use_container_width=True,
            )
        else:
            st.info("No audit logs yet. Start using LegalLens to generate activity!")


# --- Footer ---
st.sidebar.markdown("---")
st.sidebar.caption("Built by Sheena | [GitHub](#)")
