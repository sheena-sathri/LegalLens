#!/bin/bash
echo "🔍 Starting LegalLens..."
mkdir -p data/chroma_db data/sample_contracts data/playbooks

echo "🚀 Starting API server on port 8000..."
uvicorn main:app --host 0.0.0.0 --port 8000 &
API_PID=$!
sleep 3

echo "🎨 Starting Streamlit UI on port 8501..."
streamlit run frontend/streamlit_app.py --server.port 8501 --server.address 0.0.0.0 --server.headless true &
STREAMLIT_PID=$!

echo "✅ LegalLens is running!"
echo "   API: http://localhost:8000/docs"
echo "   UI:  http://localhost:8501"

wait $API_PID $STREAMLIT_PID
